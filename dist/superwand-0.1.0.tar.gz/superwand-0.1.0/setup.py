from setuptools import setup, find_packages

setup(
    name='superwand',
    version='0.1.0',
    description='Convenient posterize library. Like a magic wand to breath life to images and css.',
    long_description=open('README.md').read(),
    long_description_content_type='text/markdown',
    url='https://github.com/juleshenry/superwand',
    author='Julian Henry',
    packages=find_packages(where='src'),
    package_dir={'': 'src'},
    
    install_requires=[
        'Pillow',
        'numpy',
        'scikit-learn',
        'scipy',
        'matplotlib',
    ],
    
    package_data={
        # 'sample': ['package_data.dat'],
    },
    
    data_files=[
        ('fonts', ['fonts/arial.ttf']),
    ],
    
    entry_points={
        'console_scripts': [
            'superwand=superwand.superwand:main',
        ],
    },
    
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires='>=3.12',
)